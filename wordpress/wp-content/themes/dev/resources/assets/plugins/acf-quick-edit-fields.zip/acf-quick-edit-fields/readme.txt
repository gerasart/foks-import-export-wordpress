=== ACF Quick Edit Fields ===
Contributors: ACF Quick Edit Fields
Donate link:
Tags: image, crop, focus point
Requires at least: 4.7
Tested up to: 4.9.8
Requires PHP: 5.6
Stable tag: 2.4.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Quick Edit ACF fields

== Description ==

WordPress plugin which extends the functionality of the Advanced Custom Fields Plugin (Pro, Version 5+).
http://www.advancedcustomfields.com/pro/



== Installation ==

Follow the standard [WordPress plugin installation procedere](http://codex.wordpress.org/Managing_Plugins).

== Frequently asked questions ==

= I am lost. =

[You'll get no direction from me](https://www.youtube.com/watch?v=kx7vkfnI6jY)


== Screenshots ==

== Changelog ==

...
