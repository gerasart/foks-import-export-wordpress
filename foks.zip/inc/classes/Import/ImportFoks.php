<?php
/**
 * Created by PhpStorm.
 * User: gerasart
 * Date: 6/5/2020
 * Time: 3:36 PM
 */

namespace Foks\Import;


abstract class ImportFoks {

}
