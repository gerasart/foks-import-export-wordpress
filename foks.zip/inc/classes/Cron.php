<?php
/**
 * Created by PhpStorm.
 * User: gerasart
 * Date: 6/5/2020
 * Time: 4:00 PM
 */

namespace Foks;


class Cron {

}
