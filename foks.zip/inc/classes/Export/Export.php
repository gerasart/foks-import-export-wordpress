<?php
/**
 * Created by PhpStorm.
 * User: gerasart
 * Date: 6/5/2020
 * Time: 3:46 PM
 */

namespace Foks\Export;


class Export extends ExportFoks {

}
